# Project 2: Data Classification Using AI

# Import libraries
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

# 1. Load Dataset
data = load_iris()
X = data.data       # Features
y = data.target     # Labels

print("Dataset Loaded Successfully")
print("Features Shape:", X.shape)
print("Labels Shape:", y.shape)

# 2. Split Data (Training & Testing)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

print("\nData Split Completed")
print("Training Data:", X_train.shape)
print("Testing Data:", X_test.shape)

# 3. Apply Classification Algorithm
model = DecisionTreeClassifier()

# Train model
model.fit(X_train, y_train)

print("\nModel Training Completed")

# 4. Make Predictions
y_pred = model.predict(X_test)

# 5. Evaluate Model
accuracy = accuracy_score(y_test, y_pred)

print("\nModel Accuracy:", accuracy)

# 6. Test with New Data
sample = [[5.1, 3.5, 1.4, 0.2]]
prediction = model.predict(sample)

print("\nSample Prediction:", prediction)
print("Predicted Flower:", data.target_names[prediction][0])